package pe.edu.upeu.syscenterlife;

/*import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysVentCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/